/**
 * 
 */
$(document).ready(function(){
	
	/**
	 * tabPanel
	 */
	$('a[title]').tooltip();
	
	
   //código a ejecutar cuando el DOM está listo para recibir instrucciones.
   eventTab();
   
   
   /**
 *
 * jquery.charcounter.js version 1.2
 * requires jQuery version 1.2 or higher
 * Copyright (c) 2007 Tom Deater (http://www.tomdeater.com)
 * Licensed under the MIT License:
 * http://www.opensource.org/licenses/mit-license.php
 * 
 */
 
(function($) {
    /**
	 * attaches a character counter to each textarea element in the jQuery object
	 * usage: $("#myTextArea").charCounter(max, settings);
	 */
	
	$.fn.charCounter = function (max, settings) {
		max = max || 100;
		settings = $.extend({
			container: "<span></span>",
			classname: "label label-primary",
			format: "(%1 caracteres restantes)",
			pulse: true,
			delay: 0
		}, settings);
		var p, timeout;
		
		function count(el, container) {
			el = $(el);
			if (el.val().length > max) {
			    el.val(el.val().substring(0, max));
			    if (settings.pulse && !p) {
			    	pulse(container, true);
			    };
			};
			
			if (el.val().length > 0) {
			      $("#btntweet").removeAttr("disabled");
			}else {
				  $('#btntweet').attr('disabled','disabled');
				
			};
			
			if (settings.delay > 0) {
				if (timeout) {
					window.clearTimeout(timeout);
				}
				timeout = window.setTimeout(function () {
					container.html(settings.format.replace(/%1/, (max - el.val().length)));
				}, settings.delay);
			} else {
				container.html(settings.format.replace(/%1/, (max - el.val().length)));
			}
		};
		
		function pulse(el, again) {
			if (p) {
				window.clearTimeout(p);
				p = null;
			};
			el.animate({ opacity: 0.1 }, 100, function () {
				$(this).animate({ opacity: 1.0 }, 100);
			});
			if (again) {
				p = window.setTimeout(function () { pulse(el) }, 200);
			};
		};
		
		return this.each(function () {
			var container;
			if (!settings.container.match(/^<.+>$/)) {
				// use existing element to hold counter message
				container = $(settings.container);
			} else {
				// append element to hold counter message (clean up old element first)
				$(this).next("." + settings.classname).remove();
				container = $(settings.container)
								.insertAfter(this)
								.addClass(settings.classname);
			}
			$(this)
				.unbind(".charCounter")
				.bind("keydown.charCounter", function () { count(this, container); })
				.bind("keypress.charCounter", function () { count(this, container); })
				.bind("keyup.charCounter", function () { count(this, container); })
				.bind("focus.charCounter", function () { count(this, container); })
				.bind("mouseover.charCounter", function () { count(this, container); })
				.bind("mouseout.charCounter", function () { count(this, container); })
				.bind("paste.charCounter", function () { 
					var me = this;
					setTimeout(function () { count(me, container); }, 10);
				});
			if (this.addEventListener) {
				this.addEventListener('input', function () { count(this, container); }, false);
			};
			count(this, container);
		});
	};

})(jQuery);

$(function() {
    $(".counted").charCounter(140,{container: "#counter"});
});

     
});

/**
 * 
 * @param {Object} hashtag
 */
function getContent(hashtag, container){
        var params = {
                "hashtag" : hashtag,
                "container" : container
               
        };
        $.ajax({
                data:  params,
                url:   'content.php',
                type:  'post',
                beforeSend: function () {
                        $(container).html("<center><img src='img/sateliteload.gif'><h3><span class='label label-primary'>Explorando  tuits...</span></h3></center>");
                },
                success:  function (response) {
                        $(container).html(response);
                }
        });
}

/**
 * 
 * @param {String} next_results
 */
function getPagContent(next_results, container){
	
	   
	
	   var params = {
                "max_id" : getParameter(next_results,'max_id'),
                     "q" : getParameter(next_results,'q'),
                 "count" : getParameter(next_results,'count'),
      "include_entities" : getParameter(next_results,'include_entities'),
               "hashtag" : getParameter(next_results,'q'),
             "container" : container          
               
        };
        
        
        $.ajax({
                data:  params,
                url:   'pagcontent.php',
                type:  'post',
                beforeSend: function () {
                        $(container).html("<center><img src='img/sateliteload.gif'><h3><span class='label label-primary'>Explorando más  tuits...</span></h3></center>");
                },
                success:  function (response) {
                        $(container).html(response);
                }
        });
       
    }
    
    
 
/**
 * 
 * @param {String} next_results
 */
function statusUpdate(){
	
	   var status = $('textarea[name=message]').val();
	
	   var params = {
                  
             "status" : status  
        };
        
        
        $.ajax({
                data:  params,
                url:   'statusupdate.php',
                type:  'post',
                beforeSend: function () {
                        $(counter).html("<img src='img/loader_2.gif'>");
                },
                success:  function (response) {
                        //$(container).html(response);
                        $('textarea[name=message]').val('');
                        $(counter).html('<span class="label label-success">Tu tuit se publicó.</span>');
                       
                }
        });
       
    }
    
    
    
    
    
    /**
 * 
 * @param {String} next_results
 */
function statusRetweet(id){
		 	
	   var params = {
                  
             "id" : id 
        };
        
        
        $.ajax({
                data:  params,
                url:   'statusretweet.php',
                type:  'post',
                beforeSend: function () {
                       // $(counter).html("<img src='img/loader_2.gif'>");
                       $('#load-retweet').html("<img src='img/loader_2.gif'>");
                },
                success:  function (response) {
                        //$(container).html(response);
                        $('#load-retweet').html('<span class="label label-success">Retuiteado.</span>');
                       // alert(response);
                }
        });
       
    }
    
    
    
    

/**
 * 
 * @param {Object} hashtag
 */
function getUserShow(screen_name, container){
        var params = {
                "screen_name" : screen_name 
               
        };
        $.ajax({
                data:  params,
                url:   'showuser.php',
                type:  'post',
                beforeSend: function () {
                        $(container).html("<center><img src='img/sateliteload.gif'><h3><span class='label label-primary'>Obteniendo información...</span></h3></center>");
                },
                success:  function (response) {
                        $(container).html(response);
                }
        });
}


/**
 * 
 */
function eventTab(){
		
	
	$( "#headtab0" ).click(function() {
       getContent($('#spantab0').text(),'#tab0primary');
    });
	
	$( "#headtab1" ).click(function() {
       getContent($('#spantab1').text(),'#tab1primary');
    });
    
    $( "#headtab2" ).click(function() {
       getContent($('#spantab2').text(),'#tab2primary');
    });
    
    $( "#headtab3" ).click(function() {
       getContent($('#spantab3').text(),'#tab3primary');
    });	
    
     $( "#headtab4" ).click(function() {
       getContent($('#spantab4').text(),'#tab4primary');
    });	
    
     $( "#headtab5" ).click(function() {
       getContent($('#spantab5').text(),'#tab5primary');
    });	
    
     $( "#headtab6" ).click(function() {
       getContent($('#spantab6').text(),'#tab6primary');
    });	
    
    $( "#headtab7" ).click(function() {
       getContent($('#spantab7').text(),'#tab7primary');
    });	
    
    $( "#headtab8" ).click(function() {
       getContent($('#spantab8').text(),'#tab8primary');
    });	
    
    $( "#headtab9" ).click(function() {
       getContent($('#spantab9').text(),'#tab9primary');
    });	
    
    $( "#headtab10" ).click(function() {
       getContent($('#spantab10').text(),'#tab10primary');
    });	
    
     $( "#headtab11" ).click(function() {
       getContent($('#spantab11').text(),'#tab11primary');
    });	
       
}

/**
 * 
 * * Funcion que captura las variables pasados por GET
 * http://www.lawebdelprogramador.com/pagina.html?id=10&pos=3
 * Devuelve un array de clave=>valor
 */
function getParameter(url,parameter){
// Obtiene la cadena completa de URL
var _url = url;
/* Obtiene la posicion donde se encuentra el signo ?, 
ahi es donde empiezan los parametros */
var index = url.indexOf("?");
/* Obtiene la posicion donde termina el nombre del parametro
e inicia el signo = */
index = url.indexOf(parameter,index) + parameter.length;
/* Verifica que efectivamente el valor en la posicion actual 
es el signo = */ 
if (url.charAt(index) == "="){
// Obtiene el valor del parametro
var result = url.indexOf("&",index);
if (result == -1){result=url.length;};
// Despliega el valor del parametro
//alert((url.substring(index + 1,result)));
return (url.substring(index + 1,result));
}
}