<?php
/**
 * @file
 * User has successfully authenticated with Twitter. Access tokens saved to session and DB.
 */

/* Load required lib files. */
session_start();

require_once('twitteroauth/twitteroauth.php');
require_once('config.php');

/* If access tokens are not available redirect to connect page. */
if (empty($_SESSION['access_token']) || empty($_SESSION['access_token']['oauth_token']) || empty($_SESSION['access_token']['oauth_token_secret'])) {
    header('Location: ./clearsessions.php');
}
/* Get user access tokens out of the session. */
$access_token = $_SESSION['access_token'];

/* Create a TwitterOauth object with consumer/user tokens. */
$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_token['oauth_token'], $access_token['oauth_token_secret']);

/* Get hashtag. */
$screen_name = $_POST["screen_name"];

/* If method is set change API call made. Test is called by default. */
//$content = $connection->get('account/verify_credentials');
$content = $connection->get('users/show', array('screen_name' => $screen_name));

// Omit the normal type of picture to obtain the original size.
$profile_image = str_replace('_normal', '', $content->profile_image_url);

?>

<!--  ******************************************************************************  -->
<!--  Find the author of the tweet and encapsulate the basic information on a card..  -->
<!--  ******************************************************************************  -->

<!-- template ("Information Card"
                Bootstrap 3.1.0 Snippet by mouse0270
              ) -->
<div class="[ col-sm-6 col-md-6 ]">
				<div class="[ info-card ]">
					<!-- Show picture of the author of the tweet. -->
					<?php echo '<img style="width: 100%" src="'.$profile_image.'"/>'?>
					<div class="[ info-card-details ] animate">
						<div class="[ info-card-header ]">
							<!-- Display the full name of the author of the tweet. -->
							<h1> <?php echo $content->name?> </h1>
							<!-- Show the user name of the author of the tweet. -->
							<h3><?php echo "@".$content->screen_name?> </h3>
						</div>
						<div class="[ info-card-detail ]">
							<!-- Description -->
							<!-- Show the description of the author of the tweet. -->
							<h4><?php echo $content->description?> </h4>													
								             
								            <!-- Show the button that allows Twetter follow the author of the tweet. -->
    										<iframe allowtransparency="true" frameborder="0" scrolling="no"
  										       <?php echo 'src="//platform.twitter.com/widgets/follow_button.html?screen_name='.$screen_name.'&lang=es"';?>
  										       style="width:300px; height:20px;">
  								             </iframe>			       			
							
						</div>
					</div>
				</div>
</div>