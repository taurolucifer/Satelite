<?php
/*
 * Mauricio Chara (@emch91) emch91p@gmail.com
 *
 * The first PHP Library to support manifest-1.0 for Education Institutions API.
 */
 
/* Generic exception class
 */
if (!class_exists('University')) {
 class UniversityException extends Exception {
   // pass
 }
}

/**
 * University class
 */
class University {
	
   // Private Members
   private $file_path = null;
   private $datos = null;
   	
  /**
   * Constructor method
   * @param  
   */
   function __construct($file_path) {
		 $this->file_path = $file_path;
		 $this->readFile();		    
   }
	
   //Methods getters.
   
   
   public function getProduct() {
     return $this->datos["product"];	 
   }  
   
   
   public function getVersion() {
     return $this->datos["version"];	 
   }     
   
  
   public function getReleaseDate() {
     return $this->datos["releaseDate"];	 
   }
   
   
   public function getType() {
     return $this->datos["type"];
	 
   }    
   
  
   public function getId() {
     return $this->datos["data"]["id"];	 
   }    
   
  
   public function getTypeId() {
     return $this->datos["data"]["type_id"];	 
   }    
   
  
   public function getName() {
     return $this->datos["data"]["name"];	 
   }        
   
   
   public function getMission() {
     return $this->datos["data"]["mission"];	 
   }  
   
   
   public function getVision() {
     return $this->datos["data"]["vision"];	 
   }      
   
   
   public function getLogo() {
     return $this->datos["data"]["logo"];	 
   } 
   
    public function getBackground() {
     return $this->datos["data"]["background"];	 
   } 
   
  
   public function getHashtag() {
     return $this->datos["data"]["hashtag"];	 
   } 
   
  
   public function getFlagLabel($index) {
     return $this->datos["data"]["flag"][$index]["label"];	 
   }     
   
  
   public function getFlagName($index) {
     return $this->datos["data"]["flag"][$index]["name"];
   }   
        
   
   
   public function getFlagCode($index) {
     return $this->datos["data"]["flag"][$index]["code"];
   }          
   
  
   public function getFlagIndex($index) {
     return $this->datos["data"]["flag"][$index];
   } 

   
   public function getFlagAll() {
     return $this->datos["data"]["flag"];
   }      
   
   
   public function getHymn() {
     return $this->datos["data"]["hymn"];
   }     
   
  
   public function getHymnLetter() {
     return $this->datos["data"]["hymn"]["letter"];
   }     
   
   
   public function getHymnMusic() {
     return $this->datos["data"]["hymn"]["music"];
   }
   
   
   public function getHymnInstrumentation() {
     return $this->datos["data"]["hymn"]["instrumentation"];
   } 
   
  
   public function getHymnChoir() {
     return $this->datos["data"]["hymn"]["choir"];
   } 
   
  
   public function getHymnUrlFullHymn() {
     return $this->datos["data"]["hymn"]["url_full_hymn"];
   } 
   
   public function getFaculties() {
     return $this->datos["data"]["faculties"];
   } 
   
   
   public function getFaculty($index) {
     return $this->datos["data"]["faculties"][$index];
   } 
   
   
   public function getFacultyName($index) {
     return $this->datos["data"]["faculties"][$index]["name"];
   } 
   
   
   public function getFacultyHashtag($index) {
     return $this->datos["data"]["faculties"][$index]["hashtag"];
   } 
   
   
   public function getFacultyColorFilter($index) {
     return $this->datos["data"]["faculties"][$index]["color_filter"];
   }   
   
   
   public function getFacultyResponsible($index) {
     return $this->datos["data"]["faculties"][$index]["responsible"];
   } 
   
  
   public function getFacultyPhone($index) {
     return $this->datos["data"]["faculties"][$index]["phone"];
   } 
   
   
   public function getFacultyExt($index) {
     return $this->datos["data"]["faculties"][$index]["ext"];
   } 
   
  
   
   public function getFacultyEmail($index) {
     return $this->datos["data"]["faculties"][$index]["email"];
   }
   
  
   public function getFacultyProgramsPre($index_f) {
     return $this->datos["data"]["faculties"][$index_f]["programs_pre"];
   }

   public function getFacultyProgramPre($index_f, $index_p) {
     return $this->datos["data"]["faculties"][$index_f]["programs_pre"][$index_p];
   }   
   
   
   public function getFacultyProgramPreName($index_f, $index_p) {
     return $this->datos["data"]["faculties"][$index_f]["programs_pre"][$index_p]["name"];
   }  
   
   
   public function getFacultyProgramPreRegisterNumber($index_f, $index_p) {
     return $this->datos["data"]["faculties"][$index_f]["programs_pre"][$index_p]["register_number"];
   }  
   
   public function getFacultyProgramPreRegistryResolution($index_f, $index_p) {
     return $this->datos["data"]["faculties"][$index_f]["programs_pre"][$index_p]["registry_resolution"];
   }  
   
   
   public function getFacultyProgramPreTitleConferred($index_f, $index_p) {
     return $this->datos["data"]["faculties"][$index_f]["programs_pre"][$index_p]["title_conferred"];
   }  
   
   
   public function getFacultyProgramPreDuration($index_f, $index_p) {
     return $this->datos["data"]["faculties"][$index_f]["programs_pre"][$index_p]["duration"];
   } 
   
   
   public function getFacultyProgramPreCycle($index_f, $index_p) {
     return $this->datos["data"]["faculties"][$index_f]["programs_pre"][$index_p]["cycle"];
   }
   
   
   public function getFacultyProgramPreCredits($index_f, $index_p) {
     return $this->datos["data"]["faculties"][$index_f]["programs_pre"][$index_p]["credits"];
   }
   
    
   public function getFacultyProgramPreModality($index_f, $index_p) {
     return $this->datos["data"]["faculties"][$index_f]["programs_pre"][$index_p]["modality"];
   }
   
   
   public function getFacultyProgramPreDiurnal($index_f, $index_p) {
     return $this->datos["data"]["faculties"][$index_f]["programs_pre"][$index_p]["diurnal"];
   }
   
    
   public function getFacultyProgramPreNocturnal($index_f, $index_p) {
     return $this->datos["data"]["faculties"][$index_f]["programs_pre"][$index_p]["nocturnal"];
   }
   
    
   public function getFacultyProgramPreProfile($index_f, $index_p) {
     return $this->datos["data"]["faculties"][$index_f]["programs_pre"][$index_p]["profile"];
   }
   
    
   public function getFacultyProgramPreCurriculum($index_f, $index_p) {
     return $this->datos["data"]["faculties"][$index_f]["programs_pre"][$index_p]["curriculum"];
   }
   
  
   public function getCourses() {
     return $this->datos["data"]["course"];
   }
   
      
   
   public function getCourse($index) {
     return $this->datos["data"]["course"][$index];
   }
   
   
   public function getCourseName($index) {
     return $this->datos["data"]["course"][$index]["name"];
   }
   
   
   public function getCourseHashtag($index) {
     return $this->datos["data"]["course"][$index]["hashtag"];
   }
   
  
  
   public function getCourseResponsible($index) {
     return $this->datos["data"]["course"][$index]["responsible"];
   }
   
   
   public function getCoursePhone($index) {
     return $this->datos["data"]["course"][$index]["phone"];
   }
   
   
   public function getCourseExt($index) {
     return $this->datos["data"]["course"][$index]["ext"];
   }
   
   
   public function getCourseEmail($index) {
     return $this->datos["data"]["course"][$index]["email"];
   }
   
   
   public function getCourseProfile($index) {
     return $this->datos["data"]["course"][$index]["profile"];
   }
   
   
   public function getCourseCurriculum($index) {
     return $this->datos["data"]["course"][$index]["curriculum"];
   }
   
   
   public function getProgramsPos() {
     return $this->datos["data"]["programs_pos"];
   }
   
   
   public function getProgramPos($index) {
     return $this->datos["data"]["programs_pos"][$index];
   }
   
   public function getProgramPosRegistry_resolution($index) {
     return $this->datos["data"]["programs_pos"][$index]["registry_resolution"];
   }
   
  
   public function getProgramPosTitleConferred($index) {
     return $this->datos["data"]["programs_pos"][$index]["title_conferred"];
   }
   
  
   public function getProgramPosDuration($index) {
     return $this->datos["data"]["programs_pos"][$index]["duration"];
   }
   
   
   public function getProgramPosCycle($index) {
     return $this->datos["data"]["programs_pos"][$index]["cycle"];
   }
   
   
   public function getProgramPosCredits($index) {
     return $this->datos["data"]["programs_pos"][$index]["credits"];
   }
   
    
   public function getProgramPosModality($index) {
     return $this->datos["data"]["programs_pos"][$index]["modality"];
   }
   
    
   public function getProgramPosDiurnal($index) {
     return $this->datos["data"]["programs_pos"][$index]["diurnal"];
   }
   
   
   public function getProgramPosNocturnal($index) {
     return $this->datos["data"]["programs_pos"][$index]["nocturnal"];
   }
   
    
   public function getProgramPosProfile($index) {
     return $this->datos["data"]["programs_pos"][$index]["profile"];
   }
   
   
   public function getProgramPosCurriculum($index) {
     return $this->datos["data"]["programs_pos"][$index]["curriculum"];
   }
   
    
   public function getLibrary() {
     return $this->datos["data"]["library"];
   }
   
  
  
   public function getLibraryName() {
     return $this->datos["data"]["library"]["name"];
   }   
   
   
   public function getLibraryIntro() {
     return $this->datos["data"]["library"]["intro"];
   }   
   
  
   public function getLibraryOverview() {
     return $this->datos["data"]["library"]["overview"];
   }   
   
   
   public function getLibraryHashtag() {
     return $this->datos["data"]["library"]["hashtag"];
   }   
   
   
   public function getWelfare() {
     return $this->datos["data"]["welfare"];
   }  
   
  
   public function getWelfareTitle() {
     return $this->datos["data"]["welfare"]["label"];
   }    
   
   
   public function getWelfarePlan() {
     return $this->datos["data"]["welfare"]["plan"];
   }   
   
  
   public function getWelfareActivities() {
     return $this->datos["data"]["welfare"]["activities"];
   }   
   
   
   public function getWelfareHashtag() {
     return $this->datos["data"]["welfare"]["hashtag"];
   }   
      
   
   public function getGraduates() {
     return $this->datos["data"]["graduates"];
   }    
   
   public function getGraduatesWebSite() {
     return $this->datos["data"]["graduates"]["website"];
   }  
   
   
   public function getGraduatesTitle() {
     return $this->datos["data"]["graduates"]["label"];
   }     
   
   public function getGraduatesHashtag() {
     return $this->datos["data"]["graduates"]["hashtag"];
   }  
   
   
   public function getSocials() {
     return $this->datos["data"]["social"];
   }   
   
   public function getSocial($index) {
     return $this->datos["data"]["social"][$index];
   }     
   
   public function getSocialName($index) {
     return $this->datos["data"]["social"][$index]["name"];
   }    
   
   public function getSocialUrl($index) {
     return $this->datos["data"]["social"][$index]["profile"];
   }     
   
   public function getOnlineServices() {
     return $this->datos["data"]["online_services"];
   } 
   
   public function getOnlineService($index) {
     return $this->datos["data"]["online_services"][$index];
   }    
      
   //Methods useful.
   
   private function readFile(){
   	
		$str_datos = file_get_contents($this->file_path);
        
        if ($str_datos === FALSE) {
    		console.log("->Error getting Manifiesto");
		} else {
   			$this->datos = json_decode($str_datos,true);			
		}  
   }  
  
} 
  
?>