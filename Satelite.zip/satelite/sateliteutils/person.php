<?php
/*
 * Mauricio Chara (@emch91) emch91p@gmail.com
 *
 * The first PHP Library to support manifest-1.0 for Education Institutions API.
 */
 
/* Generic exception class
 */
if (!class_exists('Person')) {
 class PersonException extends Exception {
   // pass
 }
}

/**
 * Person class
 */
class Person {
	
   // Private Members
   private $file_path = null;
   private $datos = null;
   	
  /**
   * Constructor method
   * @param  
   */
   function __construct($file_path) {
		 $this->file_path = $file_path;
		 $this->readFile();		    
   }
	
   //Methods getters.
   
   /* Get the name*/
   public function getAutorName() {
     return $this->datos["nombre"];	 
   }  
   
   public function getDescription() {
     return $this->datos["descripcion"];	 
   }
   
   public function getPageTitle() {
     return $this->datos["titulo"];	 
   }    
   
   public function getVision() {
     return $this->datos["vision"];	 
   }
   
   public function getMision() {
     return $this->datos["mision"];	 
   }
   
   public function getAutorPic() {
     return $this->datos["imagenAutor"];	 
   }
   
    public function getSocialLabel($index) {
     return $this->datos["data"]["social"][$index]["label"];
   }   
        
   
   
   public function getSocialUrl($index) {
     return $this->datos["data"]["social"][$index]["url"];
   } 
   
   public function getVinculoLabel($index) {
     return $this->datos["data"]["vinculos"][$index]["label"];
   }  
   
   public function getVinculoEnlace($index) {
     return $this->datos["data"]["vinculos"][$index]["enlace"];
   }  
   
   public function getVinculoIcono($index) {
     return $this->datos["data"]["vinculos"][$index]["icono"];
   }
   
   public function getLabelCategoria($index) {
     return $this->datos["data"]["categorias"][$index]["label"];
   } 
   
   public function getDescripcionCategoria($index) {
     return $this->datos["data"]["categorias"][$index]["descripcion"];
   } 
   
   public function getIconoCategoria($index) {
     return $this->datos["data"]["categorias"][$index]["icono"];
   }      
   
      
   //Methods useful.
   
   private function readFile(){
   	
		$str_datos = file_get_contents($this->file_path);
        
        if ($str_datos === FALSE) {
    		console.log("->Error getting Manifiesto");
		} else {
   			$this->datos = json_decode($str_datos,true);			
		}  
   }  
  
} 
  
?>