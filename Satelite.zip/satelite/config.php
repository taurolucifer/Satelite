<?php

/**
 * @file
 * A single location to store configuration.
 */

// Twitter.
define('CONSUMER_KEY', 'OEMmxTeR6qf0n8pOlkSa7DBPJ');
define('CONSUMER_SECRET', 'kgZ0MZ6bVCREIqhQl5xOeADhjGF8N6Tz2ERKqUglkT8c9Z8MBr');
define('OAUTH_CALLBACK', 'http://localhost/satelite/callback.php');

// Manifest-1.0
define('PATH_MANIFEST', 'http://localhost/iucmc/manifest-1.0-IUCMC.json');


