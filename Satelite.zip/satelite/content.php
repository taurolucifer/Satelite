<?php
/**
 * @file
 * User has successfully authenticated with Twitter. Access tokens saved to session and DB.
 */

/* Load required lib files. */
session_start();

require_once('twitteroauth/twitteroauth.php');
require_once('config.php');

/* If access tokens are not available redirect to connect page. */
if (empty($_SESSION['access_token']) || empty($_SESSION['access_token']['oauth_token']) || empty($_SESSION['access_token']['oauth_token_secret'])) {
    header('Location: ./clearsessions.php');
}
/* Get user access tokens out of the session. */
$access_token = $_SESSION['access_token'];

/* Create a TwitterOauth object with consumer/user tokens. */
$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_token['oauth_token'], $access_token['oauth_token_secret']);

/* Get hashtag. */
$hashtag = $_POST["hashtag"];

/* Get container */
$container = $_POST["container"];

/* */
$hashtag_human = str_replace('%23', '#', $hashtag);


/* If method is set change API call made. Test is called by default. */
$content = $connection->get('search/tweets', array('q' => $hashtag_human,'count' => '10'));

/* Get prefix for DOM structure.*/
$hashtag_id = str_replace('#', '', $hashtag);



?>

<!--  *************************************************  -->
<!--  Search Results tweets encapsulated in a timeline.  -->
<!--  *************************************************  -->

<!-- template (Bootstrap Timeline: www.binarytheme.com) -->

<!-- container -->
<div class="container col-md-12 col-sm-12 col-xs-12 " >
            <div class="row ">            

                <div>
                    <div>
                        <ul class="timeline">
                        	
                        	
                        	
                        	<!-- A welcome sign at the top of the timeline. -->
                            <li class="time-label">
                                <span class="bg-yellow"><?php echo "Completado en: ".$content->search_metadata->completed_in." s" ?></span>
                                <br/>
                                <br/>
                            </li>
                            
                            <!-- Shows the current hashtag. -->
                            <li class="time-label">
                                <span class="bg-gray"> <?php 
                                
                                echo $hashtag ?>
                                
                                
                                </span>
                            </li> 
                            
                                    <!-- Browse the collection of tweets and integrate them into the timeline as items. -->                          
                                    
                                    <?php           					
										
										$counter_screen_name = 1; // DOM counter for link $ screen_name 	 
										
										// Browse the collection of tweets.
										foreach ($content->statuses as &$tweets) {											
											    
												// Fields tweet.
    											$name = $tweets->user->name;	
    											$screen_name = $tweets->user->screen_name;
												$description = $tweets->user->description;
												$text = $tweets->text;
												$date = new DateTime($tweets->created_at);
												$retuit_count = $tweets->retweet_count;
																								
                                                // DOM structure of an article in the timeline.
			                                    echo '<li>';
                                                   echo '<i class="fa fa-twitter bg-blue"></i>';
                                                   echo '<div class="timeline-item">';
												       /*  Creation date of the tweet */
                                                       echo '<span class="time"><i class="fa fa-clock-o"></i>'.$date->format('d/m/Y').'</span>';
                                                       /* User name and full name of the author of the tweet and as a pop-up displays the description of the user. */
                                                       echo '<h3 class="timeline-header"><a id ="'.$hashtag_id.$counter_screen_name.'" href="#"  data-toggle="modal" data-target=".pop-up-1" data-toggle="tooltip" data-placement="top" title="'.$description.'"> @'.$screen_name.'</a> <b  data-toggle="tooltip" data-placement="top" title="'.$description.'">'.$name.'</b></h3>';
                                                       /* Body of the tweet. */
                                                       echo '<div class="timeline-body">';
                                                           /* Tweet text. */
                                                           echo "<h5>".$text."</h5>";														 
														  
														   /* if you find multimedia content (type: photo) prints a label showing 
                                                              <img> src = attribute with the url in MEDIA_URL property.
														    * 
														    * */
														   if (isset($tweets->entities->media[0]->media_url)) {
														   	    $media = $tweets->entities->media[0]->media_url;				
															    echo '<br><img  class="thumbnail img-responsive" src="'.$media.'">';															
																
																																
														   } 

                                                            /* if you find multimedia content (type: photo) prints a label showing 
                                                              <img> src = attribute with the url in MEDIA_URL property.
														    * 
														    * */
														   if (isset($tweets->entities->urls[0]->url)) {
														   	    $url = $tweets->entities->urls[0]->url;				
															    echo '<br> <a  href="'.$url.'">'."<h5>Enlace: ".$url.'</h5></a>';															
																
																																
														   } 

                                                                                                                

                                                           														    
                                                       echo '</div>';
                                                       echo '<div class="timeline-footer">';
                                                           
                                                              echo '<a class="btn btn-primary btn-xs" onclick="statusRetweet('."'".$tweets->id_str."'".');">Retuitear</a>';
															  echo "<span id='load-retweet'></span>";
                                                             		
                                                         										
															
                                                       echo '</div>';
													   
													   /* record the event click on the link that displays the username. */
													  echo '<script>';
													  echo '$( "#'.$hashtag_id.$counter_screen_name.'").click(function() {';
													       /* Javascript method that gets called by AJAX user basic information that is passed as a parameter.
														    * This method is present in the file Satelite.js */
                                                           echo 'getUserShow("'.$screen_name.'","#container-info-user");';
                                                     echo '});';
													   	   echo '</script>';													
													   
                                                    echo '</div>';
                                                  echo '</li>';
												  
												  $counter_screen_name++;
									    }                                     
									   
									?>                   
                            <!-- End of timeline. -->
                            <li>
                                <i class="fa fa-clock-o"></i>
                                
                                <!-- Pagination -->
                                <ul class="pager">
                                	   
                                	   <?php
                                	   
                                	   	  /* 
										   * if property "next_result" exist? then save it in a variable $ next_results.
										   * and create a link to call the function "getPagContent (next_results, container)" 
                                           * JavaScript code.
										   * */
										   if (isset($content->search_metadata->next_results)) {
										             			
										             $next_results = $content->search_metadata->next_results;
											         
													 // Print HTML tag that creates the DOM structure of the link to explore more tweets.
													 echo '<li><a href="#" onclick="getPagContent(\''.$next_results.'\',\''.$container.'\')">Explorar más tweets...</a></li>';
													 
													 
										   } 
										   else {
										   	
											      // Print HTML tag that creates the DOM structure of the link to explore more tweets.
													 echo '<li><a href="#" onclick="getContent(\''.$hashtag_human.'\',\''.$container.'\')">Actualizar contenido...</a></li>'; 
											
										   } 
                                	   
                                	   
                                	   ?>
  										
  								      
                                        										
                                </ul>
                                
                            </li>
                        </ul>
                    </div>
                </div>

            </div>

</div>
<!-- /.container -->
